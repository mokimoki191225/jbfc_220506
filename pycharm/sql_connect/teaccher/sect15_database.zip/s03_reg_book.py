from sect15_database.s03_reg_data_1 import *
from sect15_database.s03_reg_data_2 import *
from sect15_database.s03_reg_data_3 import *

if __name__=="__main__":
    pass
